package before;

public class Fax  implements MultifunctionPrinter {
    @Override
    public void fax() {}
    @Override
    public void copy() {}
    @Override
    public void print() {}
}