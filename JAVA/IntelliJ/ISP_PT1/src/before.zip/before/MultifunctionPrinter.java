package before;

interface MultifunctionPrinter {
    public void fax();
    public void copy();
    public void print();
}