package before;

public class Copy implements MultifunctionPrinter {
    @Override
    public void fax() {}
    @Override
    public void copy() {}
    @Override
    public void print() {}
}
